package com.example.tasksharedpreference

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
